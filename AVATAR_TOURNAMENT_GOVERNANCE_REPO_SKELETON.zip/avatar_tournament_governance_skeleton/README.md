# Avatar Tournament + Avatar Governance Skeleton

This pack is additive-first. It gives you file-by-file skeleton code for:

- SQLAlchemy models
- Pydantic schemas
- services/avatar tournament + governance engines
- FastAPI route skeletons

## Wire points to patch in your monorepo

- Replace `get_db()` stubs in API files with your real DB session dependency.
- Register models in your metadata bootstrap / alembic env.
- Include routers in your API app.
- Patch `brain_decision_engine`, `brain_feedback_service`, `publish_scheduler`, and `render_execution` to call these services.

## Expected next steps

1. Add migrations for the new tables.
2. Persist debug/explanation payloads more richly.
3. Implement DB-backed historical pair stats.
4. Replace placeholder scoring heuristics with your real avatar engines.
